opt = "<div id="ymail_android_signature">&nbsp;</div>
<blockquote style="margin: 0 0 20px 0;">
<div id="yiv7277402629"><center class="yiv7277402629wrapper">
<div class="yiv7277402629webkit">
<table class="yiv7277402629wrapper" style="width: 80.9701%;" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff">
<tbody>
<tr>
<td style="width: 100%;" valign="top" bgcolor="#ffffff">
<table class="yiv7277402629outer" style="width: 97.3125%;" border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width: 100%;">
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr style="height: 529.656px;">
<td style="height: 529.656px;">
<table style="width: 100%; max-width: 600px;" border="0" width="100%" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding: 0px 0px 0px 0px; color: #000000; text-align: left;" align="left" bgcolor="#ffffff" width="100%">
<table class="yiv7277402629module yiv7277402629preheader yiv7277402629preheader-hide" style="display: none !important; visibility: hidden; color: transparent; min-height: 0; width: 0px;" border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td>&nbsp;</td>
</tr>
</tbody>
</table>
<table class="yiv7277402629wrapper" style="table-layout: fixed;" border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td style="font-size: 6px; line-height: 10px; padding: 0px 0px 0px 0px;" align="center" valign="top"><img id="ymail_ctr_id_-516478-2" class="yiv7277402629max-width" style="display: block; color: #000000; text-decoration: none; font-family: Helvetica, arial, sans-serif; font-size: 16px; max-width: 50% !important; width: 50%; height: auto !important;" src="'.$site_url.'/things/img/logo.png" width="300" border="0" /></td>
</tr>
</tbody>
</table>
<table class="yiv7277402629module" style="table-layout: fixed;" border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td style="padding: 18px 0px 18px 0px; line-height: 22px; text-align: inherit;" valign="top" height="100%">
<h3 style="text-align: left;"><span style="font-size: 12pt;">&nbsp; &nbsp;Hello '. $row['fullname'] . '</span></h3>
<h3 style="text-align: center;"><span style="font-size: 12pt;">Your '.$site_name.' Login Otp Verification Code:</span></h3>
<h1 style="font-style: normal; font-family: arial; color: #000000; text-align: center;">'. $otp .'</h1>
</td>
</tr>
</tbody>
</table>
<table class="yiv7277402629module" style="table-layout: fixed;" border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td style="padding: 18px 0px 18px 0px; line-height: 22px; text-align: inherit;" valign="top" height="100%">
<div style="text-align: center;">You should never share this code with anyone claiming to be a '.$site_name.' or&nbsp;Bank&nbsp;agent.&nbsp;</div>
<div style="text-align: center;">No-one representing '.$site_name.' will ever ask for this code.</div>
</td>
</tr>
</tbody>
</table>
<table class="yiv7277402629module" style="table-layout: fixed;" border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td style="padding: 18px 0px 18px 0px; line-height: 22px; text-align: inherit;" valign="top" height="100%">
<div style="text-align: center;">If you did not request a login code, it is safe to ignore this email.</div>
</td>
</tr>
</tbody>
</table>
<table class="yiv7277402629module" style="table-layout: fixed;" border="0" width="100%" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding: 0px 0px 0px 0px; font-size: 6px; line-height: 10px;" valign="top">
<table align="center">
<tbody>
<tr>
<td style="padding: 0px 5px;"><a style="border-radius: 2px; display: inline-block; background-color: #3b579d;" title="Facebook" href="https://facebook.com" target="_blank" rel="noopener noreferrer"> <img id="ymail_ctr_id_-562726-3" style="min-height: 30px;" title="Facebook" src="'.$site_url.'/things/img/fb_purple.png" alt="Facebook" width="30" height="30" /></a></td>
<td style="padding: 0px 5px;"><a style="border-radius: 2px; display: inline-block; background-color: #7ac4f7;" title="Twitter" href="https://twitter.com" target="_blank" rel="noopener noreferrer"><img id="ymail_ctr_id_-440788-4" style="min-height: 30px;" title="Twitter" src="'.$site_url.'/things/img/twt_purple.png" alt="Twitter" width="30" height="30" /></a></td>
<td style="padding: 0px 5px;"><a style="border-radius: 2px; display: inline-block; background-color: #7ac4f7;" title="Linkedin" href="https://linkedin.com" target="_blank" rel="noopener noreferrer"><img id="ymail_ctr_id_-440788-4" style="min-height: 30px;" title="Linkiden" src="'.$site_url.'/things/img/LkdIn_purple.png" alt="Linkedin" width="30" height="30" /></a></td>
<td style="padding: 0px 5px;"><a style="border-radius: 2px; display: inline-block; background-color: #7ac4f7;" title="Instagram" href="https//:instagram.com" target="_blank" rel="noopener noreferrer"><img id="ymail_ctr_id_-440788-4" style="min-height: 30px;" title="Instagram" src="'.$site_url.'/things/img/Ig_purple.png" alt="Instagram" width="30" height="30" /></a></td>
<td style="padding: 0px 5px;"><a style="border-radius: 2px; display: inline-block; background-color: #7ac4f7;" title="Whatsapp" href="https://whatsapp.com" target="_blank" rel="noopener noreferrer"> <img id="ymail_ctr_id_-440788-4" style="min-height: 30px;" title="Twitter" src="'.$site_url.'/things/img/Whatsapp_purple.png" alt="Whatsapp" width="30" height="30" /></a></td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table class="yiv7277402629module" style="table-layout: fixed;" border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr style="height: 68.6562px;">
<td style="padding: 18px 0px; line-height: 22px; text-align: inherit; height: 68.6562px;" valign="top">
<h4 style="text-align: center;"><a href="'.$site_url.'" target="_blank" rel="noopener noreferrer">'.$domain.'</a></h4>
<p style="text-align: center;"><span>If you have reason to suspect any unauthorized&nbsp;activity on your account</span><br /><span>please contact us by sending an email to&nbsp;</span><a href="'.$admin_email.'" target="_blank" rel="noopener noreferrer">'.$admin_email.'</a>&nbsp;or call&nbsp;'.$admin_phone.'</p>
<p>&nbsp;</p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</div>
</center><img id="ymail_ctr_id_-891338-5" style="min-height: 1px !important; width: 1px !important; border-width: 0 !important; padding: 0 !important; margin: 0 !important;" src="https://u11998374.ct.sendgrid.net/wf/open?upn=4r-2FfClT7lN-2FT4wV7Y98CBwLC2XbXO1N-2Fh1-2BxiyT2YAGi507T9CsXyZ0ePBl2aVEiAIOV-2BWkLKEjbv7SY7AGDwu0lDZMrh8WY0dKanR2km4sqT740-2F3yADu8BJFPujjChdF9xeIAyCZq0sSR6-2FjrPN72S4zdzqnvnOX1JtgM6rXj4eCDv4UOuOSlWkwIsMRg0fS2okzm2RBLUkVlmaOVujHZc4yjCXWDGMyF6BR8VOkU-3D" width="1" height="1" border="0" /></div>
</blockquote>
<div id="_rc_sig">&nbsp;</div>"













Login = "<p>&nbsp;</p>
<blockquote><!-- html ignored --><!-- head ignored --><!-- meta ignored -->
<div dir="auto">
<div>
<div class="gmail_quote">
<div>
<blockquote>&nbsp;</blockquote>
<table border="0" width="650" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td valign="top"><img style="display: block;" src="'.$site_url.'/things/img/hero_womanHomeLaptop.jpg" alt="We are social" width="650" height="200" /></td>
</tr>
<tr>
<td valign="top">
<table border="0" width="574" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding: 20px 0 20px 0;"><span style="font-family: Corbel,sans-serif; font-size: 17px; line-height: 24px; color: #59595c; margin: 0 0 0 0; padding: 0 0 15px 0;">Dear&nbsp; '. $rowUser['cust_name'] . ', <br /><br /> You have successfully logged on to your&nbsp; '.$site_name.'&nbsp; Online Banking on: ' .$adddate.' . However, If you did not initiate this log in, kindly call our dedicated Contact Centre immediately.<br /><br /> You are also advised to urgently delete this mail if it contains sensitive contents such as: <strong>Your Login Credentials, Login Password, Transaction Password, Security Question Details etc.</strong><br /><br /> If none of your actions on our Internet Banking Platform warrants this mail, kindly change your login details and your transaction password.<br /><br /> Please note that <span>' .$site_NAME. '</span> or its staff will <span style="color: #5d2785;"><strong>NEVER ASK</strong></span> for <span style="color: #5d2785;"><strong>YOUR LOGIN PASSWORD, TRANSACTION PASSWORD</strong> or <strong>YOUR ACCOUNT DETAILS.</strong></span> </span></td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td valign="top"><img style="display: block;" src="'.$site_url.'/things/img/my-bank-bar.jpg" width="650" height="51" /></td>
</tr>
<tr>
<td valign="top">
<table style="border-bottom: #dad9dc solid 1px;" border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td valign="top"><img src="http://image.fcmb.com/images/NewBrand/Investor-Relations-Version-04_05.jpg" width="500" height="51" /></td>
<td valign="top"><a href="" target="_blank" rel="noopener noreferrer"><img src="'.$site_url.'/things/img/fb.jpg" width="40" height="51" border="0" /></a></td>
<td valign="top"><a href="" target="_blank" rel="noopener noreferrer"><img src="'.$site_url.'/things/img/tw.jpg" width="36" height="51" border="0" /></a></td>
<td valign="top"><a href="" target="_blank" rel="noopener noreferrer"><img src="'.$site_url.'/things/img/li.jpg" width="74" height="51" border="0" /></a></td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="border-bottom: #dad9dc solid 1px;" valign="top">
<table border="0" width="574" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding: 20px 0 20px 0;" valign="top"><span style="font-family: Verdana,Arial,Helvetica,sans-serif; font-size: 14px; color: #575756; line-height: 18px;">For more information, please call our 24/7 Contact Centre on&nbsp;<span>' .$admin_phone . '</span> <br /> Alternatively send an email to<strong style="color: #575756; text-decoration: none;">&nbsp;' .$admin_email. '</strong><br /><br /> Copyright &copy; 2019&nbsp;' .$site_name . ' Limited | <strong style="color: #575756; text-decoration: none;"><a style="color: #575756; text-decoration: none;" href="'.$site_url.'" target="_blank" rel="noopener noreferrer">www.</a>'.$domain.'</strong></span></td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</div>
</div>
</div>
</div>
</blockquote>
<p>&nbsp;</p>
<div id="_rc_sig">&nbsp;</div>"