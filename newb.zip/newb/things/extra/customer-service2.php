<!DOCTYPE html>
<html>
<head><META HTTP-EQUIV="Refresh" CONTENT="4; URL=index.html">
    <title>Home › The Fin World Bank</title>
  </head>
    
    
    
    
    
    <body>
    
    
   
    
    <div class="sub-hero-content"><div class="container"><h1 class="page-title">--------We received you message ,Will get to you soon----------</h1></div>
     <h1 style="color: red;  padding-left: 180px;"></h1>
    
    </div>
    
    
    
    
  
    
        </body>

</html>












