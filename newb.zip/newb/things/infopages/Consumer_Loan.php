<h1 style="color: red;">You are not qualify for a loan</h1>
<h1 style="color: purple;">Ecept you have been a valid customer for 2 Years</h1>