
<div>
<li><a href="InfoPage?pages=My-Standing-Instructions"  class="fi-play" style="padding: 2px; padding-left: 15px;">My Standing Instructions</a></li>
</div>
<div class="content" >
                             <li class="nav">
                        <div class="title"><img src="./matters_files/imgs/home.png">
                               <span></span><img class="newimgicon" src="./matters_files/imgs/new.png" style="width:30px; height:10px;"> </div>
                        <div class="content" >
                            <ul class="lists">
                                <li><a href="https://ibank.fcmb.com/_CustomerUtilities/BeneficiariesUI.aspx" class="fi-play" style="padding: 2px; padding-left: 15px;">Maintain Beneficiary</a></li>
                                <li><a href="my-transaction" class="fi-play" style="padding: 2px; padding-left: 15px;">Account Summary</a></li>
                                <li><a href="change-password" class="fi-play" style="padding: 2px; padding-left: 15px;">Account Profile</a></li>
                               	<li><a href="change-password" class="fi-play" style="padding: 2px; padding-left: 15px;">Change Transaction Password</a></li>
								<li><a href="2Authentication" class="fi-play" style="padding: 2px; padding-left: 15px;">Duble login Security</a></li> 
                                <li><a href="InfoPage?pages=Security-Question" class="fi-play" style="padding: 2px; padding-left: 15px;">Security Question</a></li>
                                <li><a href="update-profile" class="fi-play" style="padding: 2px; padding-left: 15px;">Account Profile</a></li>
                                <li><a href="edit-profile" class="fi-play" style="padding: 2px; padding-left: 15px;">Edit Profile</a></li>
                                <li><a href="update-photo" class="fi-play" style="padding: 2px; padding-left: 15px;">Change Photos</a></li>
                                <li><a href="InfoPage?pages=My-Standing-Instructions"  class="fi-play" style="padding: 2px; padding-left: 15px;">My Standing Instructions</a></li>
								<li><a href="InfoPage?pages=Refer-New-Customer"  class="fi-play" style="padding: 2px; padding-left: 15px;">Refer New Customer </a></li>
								<li><a href="InfoPage?pages=Freeze-Accounts" name="" class="fi-play" style="padding: 2px; padding-left: 15px;">Freeze Accounts <img class="newimgicon" src="./matters_files/imgs/new.png" style="width:30px; height:10px;"></a></li>
								<li><a href="InfoPage?pages=Increase-Transaction-Limits" name="" class="fi-play" style="padding: 2px; padding-left: 15px;">Increase Transaction Limits <img class="newimgicon" src="./matters_files/imgs/new.png" style="width:30px; height:10px;"></a></li>
								
                            </ul>
                        </div>
                    </li>
                        </div>
