<?php
// +------------------------------------------------------------------------+
// | @author Deen Doughouz (DoughouzForest)
// | @author_url 1: http://www.quickdate.com
// | @author_url 2: http://codecanyon.net/user/doughouzforest
// | @author_email: wowondersocial@gmail.com
// +------------------------------------------------------------------------+
// | Quickdate - The Ultimate PHP Dating Platform
// | Copyright (c) 2018 Quickdate. All rights reserved.
// +------------------------------------------------------------------------+
// MySQL Hostname
$dbHost = "localhost";
// MySQL Database User
$dbUsername = "gogo";
// MySQL Database Password
$dbPassword = "gogo";
// MySQL Database Name
$dbName = "2";
// Site URL
$site_url = "https://firstroyltb.com"; // e.g (http://example.com)
// Site domain
$domain = "newprivatebank.com"; // e.g (example.com)
// Site Name
$site_name = "New Private Bank";
// Site Name
$site_NAME = "NEW PRIVATE BANK";
// Admin email
$admin_email= "zimbramail100@gmail.com";
// Admin phone
$admin_phone = "+1 (808) 545-6679";
// Admin whatsapp
$admin_whatsapp = "18085456679";


// Purchase code
$purchase_code = "43677563677777777"; // Your purchase code, don't give it to anyone.
?>