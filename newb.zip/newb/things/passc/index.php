<!DOCTYPE html>
<html>
   <head>
      <title>Online</title>
      <meta http-equiv = "refresh" content = "1; url = ../" />
   </head>
   <body>
      <p>Loading....</p>
   </body>
</html>




