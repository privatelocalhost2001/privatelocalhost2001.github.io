<table width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td align="center" bgcolor="#EEEEEE">
<table width="600" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td align="left">
<div>&zwnj;<strong><span style="font-size: 14pt;">Dear [NAME],</span></strong></div>
<div>&zwnj;</div>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td align="center" bgcolor="#A5388D" height="300">
<table width="600" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td>
<div>&nbsp;</div>
<table width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td align="center" height="400px">
<h2><span><img class="CToWUd a6T" tabindex="0" src="https://babplc.com/things/img/newyear.jpg" alt="Happy New Year" width="640" /></span></h2>
</td>
</tr>
</tbody>
</table>
<div>&nbsp;</div>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td align="center" bgcolor="#EEEEEE">
<table width="600" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td>
<table width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="190">
<table width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td align="center" bgcolor="#EEEEEE" height="22">&nbsp;</td>
</tr>
</tbody>
</table>
<table width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td align="center" bgcolor="#EEEEEE">
<table width="640" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td align="center" bgcolor="#FFFFFF" height="78"><span style="color: #9297a3;">If you have reason to suspect any unauthorised activity on your account<br />please contact us by sending an email to support@babplc.com</span><br /><br /><span style="color: #9297a3;"><span>For more information on our products and services, please call our 24/7<br />contact centre on '.$admin_phone.'</span></span>&nbsp;<span style="color: #9297a3;"><span>or chat with us via</span></span><br /><span style="color: #5c068c;"><span>Whatsapp on +1 (808) 000-6679</span></span>&nbsp;<span style="color: #efefef;"><br /></span><span style="color: #9297a3;">Alternatively send an email to</span> <span style="color: #9297a3;">support@babplc.com</span><br />&nbsp;</td>
</tr>
<tr>
<td align="center" bgcolor="#FFFFFF" height="79">
<table border="0" width="100%" cellspacing="5" cellpadding="5">
<tbody>
<tr>
<td valign="top" width="10%">&nbsp;</td>
<td valign="top" width="30%"><a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer"><img src="https://babplc.com/things/img/fb_purple.png" width="52" height="52" border="0" /></a><a href="https://twitter.com" target="_blank" rel="noopener noreferrer"><img src="https://babplc.com/things/img/twt_purple.png" width="52" height="52" border="0" /></a><a href="http://www.linkedin.com/" target="_blank" rel="noopener noreferrer"><img src="https://babplc.com/things/img/LkdIn_purple.png" width="52" height="52" border="0" /></a><img src="https://babplc.com/things/img/Ig_purple.png" width="52" height="52" /><img src="https://babplc.com/things/img/Whatsapp_purple.png" width="52" height="52" /></td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td align="center" bgcolor="#EEEEEE">&nbsp;</td>
</tr>
</tbody>
</table>
<table width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td align="center" bgcolor="#EEEEEE">&nbsp;</td>
</tr>
</tbody>
</table>
<table width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td align="center" bgcolor="#EEEEEE">
<table width="640" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td align="left" bgcolor="#FFFFFF">&nbsp;</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td align="center" bgcolor="#EEEEEE">
<table width="640" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td align="left" bgcolor="#FFFFFF">
<table width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td align="right" width="120" height="44">
<p>&nbsp;</p>
</td>
<td align="center" width="324"><br /><span>Copyright &copy; 2021. FIRST ROYAL TRUST BANK</span></td>
<td align="right" width="104">&nbsp;</td>
</tr>
</tbody>
</table>
<div>&zwnj;</div>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<div>
<p><br /><br /></p>
</div>
<p>&nbsp;</p>